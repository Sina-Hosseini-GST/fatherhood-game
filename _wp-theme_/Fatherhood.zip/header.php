<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo pods( 'fatherhood_content' )->find()->display( 'browser_title' ); ?></title>
  <?php wp_head(); ?>
  <!-- Designed and developed by Sina Hosseini -->
</head>
<body class="text-white font-roboto-thin">
  <a target="_blank" href="<?php echo pods( 'fatherhood_content' )->find()->display( 'demo_box_link' ); ?>" class="bg-c-blue-5 hover:bg-c-blue-4 transition-colors duration-200 group z-20 flex justify-center items-center rounded shadow-c-2 xl:w-c-93 xl:h-c-156 lg:w-c-158 lg:h-c-159 md:w-c-161 md:h-c-160 w-c-164 h-c-163 xl:gap-c-3 lg:gap-c-157 md:gap-c-76 gap-c-162 fixed xl:right-c xl:bottom-c lg:right-c-87 lg:bottom-c-87 md:right-c-29 md:bottom-c-29 right-c-88 bottom-c-88">
    <div>
      <?php echo pods( 'fatherhood_content' )->find()->display( 'demo_box_icon' ); ?>
    </div>
    <div class="uppercase xl:text-c-32 lg:text-c-35 md:text-c-36 text-c-33 xl:tracking-c-26 lg:tracking-c-27 md:tracking-c-28 tracking-c-29 xl:[word-spacing:.125vw] lg:[word-spacing:.0755rem] md:[word-spacing:.07323rem] [word-spacing:.07085rem]">
      <?php echo pods( 'fatherhood_content' )->find()->display( 'demo_box_text' ); ?>
    </div>
  </a>

  <header class="h-screen bg-cover bg-center bg-no-repeat xl:pt-c-14 pt-14 flex flex-col items-center" style="background-image: url(' <?php echo pods( 'fatherhood_content' )->find()->display( 'header_background_image' ); ?> ');">
    <div class="xl:w-1/2 lg:w-c-16 md:w-80 w-c-30">
      <img class="w-full" src="<?php bloginfo( 'template_directory' ); ?>/css/assets/img/Fatherhood White.png" alt="LogoType Image">
    </div>

    <div class="flex flex-col justify-center flex-1 text-center xl:w-1/2 lg:w-c-16 md:w-80 w-c-30 text-shadow-c xl:gap-c-40 xl:text-c xl:[word-spacing:.25vw] xl:tracking-c lg:gap-c-41 lg:text-c-11 lg:[word-spacing:.14rem] lg:tracking-c-9 md:gap-c-42 md:text-c-16 md:[word-spacing:.12rem] md:tracking-c-10 gap-1 text-c-18 [word-spacing:.1rem] tracking-c-11">
      <div class="xl:leading-c-10 lg:leading-c-11 md:leading-c-12 leading-c-13">
        <?php echo pods( 'fatherhood_content' )->find()->display( 'top_title' ); ?>
      </div>
      <div class="flex justify-center">
        <?php echo pods( 'fatherhood_content' )->find()->display( 'bottom_left_text' ); ?>
        <span class="[writing-mode:vertical-lr] xl:text-c-14 xl:mt-c-4 xl:mx-c-31 lg:text-c-15 lg:mt-c-33 lg:mx-c-32 md:text-c-17 md:mt-1 md:mx-c-36 text-c-11 mt-c-39 mx-c-38">
          <?php echo pods( 'fatherhood_content' )->find()->display( 'bottom_center_text' ); ?>
        </span>
        <?php echo pods( 'fatherhood_content' )->find()->display( 'bottom_right_text' ); ?>
      </div>
    </div>
  </header>