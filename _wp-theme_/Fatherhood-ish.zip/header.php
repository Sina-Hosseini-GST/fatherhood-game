<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="It's a tale of SACRIFICE, as an ANTI-WAR story, to see wars from the eyes of a FATHER">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo pods( 'fatherhood_content' )->find()->display( 'browser_title' ); ?></title>
  <?php wp_head(); ?>
  <!-- Designed and developed by Sina Hosseini -->
</head>
<body class="text-white font-roboto-thin">
  <a target="_blank" href="<?php echo pods( 'fatherhood_content' )->find()->display( 'demo_box_link' ); ?>" class="bg-c-blue-5 hover:bg-c-blue-4 transition-colors duration-200 group z-20 flex justify-center items-center rounded shadow-c-2 xl:w-c-93 xl:h-c-156 lg:w-c-158 lg:h-c-159 md:w-c-161 md:h-c-160 w-c-164 h-c-163 xl:gap-c-3 lg:gap-c-157 md:gap-c-76 gap-c-162 fixed xl:right-c xl:bottom-c lg:right-c-87 lg:bottom-c-87 md:right-c-29 md:bottom-c-29 right-c-88 bottom-c-88">
    <div>
      <?php echo pods( 'fatherhood_content' )->find()->display( 'demo_box_icon' ); ?>
    </div>
    <div class="uppercase xl:text-c-32 lg:text-c-35 md:text-c-36 text-c-33 xl:tracking-c-26 lg:tracking-c-27 md:tracking-c-28 tracking-c-29 xl:[word-spacing:.125vw] lg:[word-spacing:.0755rem] md:[word-spacing:.07323rem] [word-spacing:.07085rem]">
      <?php echo pods( 'fatherhood_content' )->find()->display( 'demo_box_text' ); ?>
    </div>
  </a>

  <header class="h-screen bg-cover bg-center bg-no-repeat xl:pt-c-14 pt-14 flex flex-col items-center" style="background-image: url(' <?php echo pods( 'fatherhood_content' )->find()->display( 'header_background_image' ); ?> ');">
    <div class="xl:w-1/2 lg:w-c-16 md:w-80 w-c-30">
      <img class="w-full" src="<?php bloginfo( 'template_directory' ); ?>/css/assets/img/Fatherhood White.png" alt="LogoType Image">
    </div>

    <div class="flex justify-center items-center flex-1 text-center xl:w-1/2 lg:w-c-16 md:w-80 w-c-30 text-shadow-c xl:gap-c-40 xl:text-c xl:[word-spacing:.25vw] xl:tracking-c lg:gap-c-41 lg:text-c-11 lg:[word-spacing:.14rem] lg:tracking-c-9 md:gap-c-42 md:text-c-16 md:[word-spacing:.12rem] md:tracking-c-10 gap-1 text-c-18 [word-spacing:.1rem] tracking-c-11">
      <a target="_blank" class="xl:h-c-74 lg:h-16 md:h-c-165 h-c-166 xl:gap-c lg:gap-4 md:gap-c-168 gap-c-76 xl:px-c-73 lg:px-8 md:px-c-167 px-c-29 rounded flex items-center bg-c-black-2 hover:bg-black transition-colors duration-200" href="https://store.steampowered.com/app/2180850/Fatherhood/">
        <div>
          <svg class="xl:w-c-6 lg:w-10 md:w-6 w-5 h-auto" xmlns="http://www.w3.org/2000/svg" role="img" fill="currentColor" color="" viewBox="0.02 0 23.96 24"><path d="M11.979 0C5.678 0 .511 4.86.022 11.037l6.432 2.658c.545-.371 1.203-.59 1.912-.59.063 0 .125.004.188.006l2.861-4.142V8.91c0-2.495 2.028-4.524 4.524-4.524 2.494 0 4.524 2.031 4.524 4.527s-2.03 4.525-4.524 4.525h-.105l-4.076 2.911c0 .052.004.105.004.159 0 1.875-1.515 3.396-3.39 3.396-1.635 0-3.016-1.173-3.331-2.727L.436 15.27C1.862 20.307 6.486 24 11.979 24c6.627 0 11.999-5.373 11.999-12S18.605 0 11.979 0zM7.54 18.21l-1.473-.61c.262.543.714.999 1.314 1.25 1.297.539 2.793-.076 3.332-1.375.263-.63.264-1.319.005-1.949s-.75-1.121-1.377-1.383c-.624-.26-1.29-.249-1.878-.03l1.523.63c.956.4 1.409 1.5 1.009 2.455-.397.957-1.497 1.41-2.454 1.012H7.54zm11.415-9.303c0-1.662-1.353-3.015-3.015-3.015-1.665 0-3.015 1.353-3.015 3.015 0 1.665 1.35 3.015 3.015 3.015 1.663 0 3.015-1.35 3.015-3.015zm-5.273-.005c0-1.252 1.013-2.266 2.265-2.266 1.249 0 2.266 1.014 2.266 2.266 0 1.251-1.017 2.265-2.266 2.265-1.253 0-2.265-1.014-2.265-2.265z"></path></svg>
        </div>
        <div class="whitespace-nowrap xl:text-c-47 lg:text-c-48 md:text-c-49 text-c-13 xl:tracking-c-25 lg:tracking-c-50 md:tracking-c-51 tracking-c-52 xl:[word-spacing:.25vw] lg:[word-spacing:.125rem] md:[word-spacing:.075rem] [word-spacing:.063rem]">
          WISHLIST ON STEAM
        </div>
      </a>
    </div>
  </header>